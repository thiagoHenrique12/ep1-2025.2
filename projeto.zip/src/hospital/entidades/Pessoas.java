package hospital.entidades;

public class Pessoas {
}
